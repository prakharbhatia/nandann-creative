<?php
/**
 * Plugin Name:       Pixlify - WebP & Image Optimizer
 * Plugin URI:        https://www.nandann.com/pixlify-image-optimizer
 * Update URI:        https://www.nandann.com/pixlify-image-optimizer
 * Description:       Convert images to WebP/AVIF, resize, compress lossy/lossless, batch process via cron, and detect duplicate or unused images. 100% free, no API keys, no quotas.
 * Version:           1.3.4
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Prakhar Bhatia
 * Author URI:        https://www.nandann.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       pixlify-image-optimizer
 */

defined( 'ABSPATH' ) || exit;

define( 'PIXLIFY_VERSION',  '1.3.4' );
define( 'PIXLIFY_FILE',     __FILE__ );
define( 'PIXLIFY_DIR',      plugin_dir_path( __FILE__ ) );
define( 'PIXLIFY_URL',      plugin_dir_url( __FILE__ ) );
define( 'PIXLIFY_BASENAME', plugin_basename( __FILE__ ) );

/**
 * License secret — used to sign and verify PXLF license keys.
 *
 * ⚠  IMPORTANT: Replace this with your own long random string before distributing
 *    the plugin.  The same value must be set in tools/generate-key.php (GENERATOR_SECRET).
 *
 * Generate a good secret:  php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
 */
if ( ! defined( 'PIXLIFY_LICENSE_SECRET' ) ) {
    define( 'PIXLIFY_LICENSE_SECRET', '9a2f3fa0fdaebd27c7cd4eb5729f2fb0a242b1be296b23abc8d047c577f14f80' );
}

require_once PIXLIFY_DIR . 'includes/class-loader.php';
Pixlify_Loader::init();

register_activation_hook( __FILE__,   array( 'Pixlify_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Pixlify_Plugin', 'deactivate' ) );
register_uninstall_hook( __FILE__,    'pixlify_uninstall_hook' );

function pixlify_uninstall_hook() {
    Pixlify_Plugin::uninstall();
}

add_filter( 'plugin_action_links_' . PIXLIFY_BASENAME, 'pixlify_action_links' );
function pixlify_action_links( $links ) {
    $settings_url = esc_url( admin_url( 'admin.php?page=pixlify-settings' ) );
    $license_url  = esc_url( admin_url( 'admin.php?page=pixlify-license' ) );

    array_unshift( $links, '<a href="' . $settings_url . '">' . esc_html__( 'Settings', 'pixlify-image-optimizer' ) . '</a>' );

    // Show a highlighted License link when no key is active.
    if ( class_exists( 'Pixlify_License' ) && ! Pixlify_License::is_licensed() ) {
        $links[] = '<a href="' . $license_url . '" style="color:#d97706;font-weight:600;">' . esc_html__( 'Activate License', 'pixlify-image-optimizer' ) . '</a>';
    } else {
        $links[] = '<a href="' . $license_url . '">' . esc_html__( 'License', 'pixlify-image-optimizer' ) . '</a>';
    }

    return $links;
}
