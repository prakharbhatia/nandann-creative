<?php
/**
 * Pixlify License — validates PXLF signed license keys.
 *
 * Key structure  (16 raw bytes → 32 hex chars):
 *   Byte   0    : type  (0x01 = trial, 0x02 = unlimited)
 *   Bytes  1–4  : expiry as big-endian uint32 Unix timestamp  (0x00000000 = no expiry)
 *   Bytes  5–7  : random nonce (3 bytes — prevents identical keys for same config)
 *   Bytes  8–15 : first 8 bytes of HMAC-SHA256( bytes[0..7], PIXLIFY_LICENSE_SECRET )
 *
 * Human-readable format: PXLF-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX
 *   (32 hex chars split into 4 groups of 8, prefixed with PXLF-)
 */
defined( 'ABSPATH' ) || exit;

class Pixlify_License {

    // ── Option / transient keys ────────────────────────────────────────────────
    const OPTION_KEY      = 'pixlify_license_key';
    const CACHE_TRANSIENT = 'pixlify_license_status';
    const CACHE_TTL       = DAY_IN_SECONDS;

    // ── Key types ──────────────────────────────────────────────────────────────
    const TYPE_TRIAL     = 0x01;
    const TYPE_UNLIMITED = 0x02;

    // ── Status codes ───────────────────────────────────────────────────────────
    const STATUS_VALID       = 'valid';       // unlimited, not expired
    const STATUS_TRIAL       = 'trial';       // trial, not expired
    const STATUS_EXPIRED     = 'expired';     // was valid but past expiry
    const STATUS_INVALID     = 'invalid';     // bad signature / wrong format
    const STATUS_UNLICENSED  = 'unlicensed';  // no key stored

    // ── Public API ─────────────────────────────────────────────────────────────

    /**
     * Return the current license status array (uses transient cache).
     *
     * Shape: {
     *   status     : string (one of STATUS_* constants),
     *   type       : string ('trial'|'unlimited'|''),
     *   expires_at : int    (Unix timestamp, 0 = never),
     *   days_left  : int,
     *   message    : string (human-readable),
     * }
     */
    public static function get_status(): array {
        $cached = get_transient( self::CACHE_TRANSIENT );
        if ( false !== $cached && is_array( $cached ) ) {
            return $cached;
        }

        $stored_key = get_option( self::OPTION_KEY, '' );

        if ( empty( $stored_key ) ) {
            $result = self::make_result( self::STATUS_UNLICENSED );
        } else {
            $result = self::validate_raw( $stored_key );
        }

        // Cache successes for 24 h; non-successful states are not cached so that
        // re-entering a key (or fixing the key server) takes effect immediately.
        if ( in_array( $result['status'], [ self::STATUS_VALID, self::STATUS_TRIAL ], true ) ) {
            set_transient( self::CACHE_TRANSIENT, $result, self::CACHE_TTL );
        }

        return $result;
    }

    /**
     * Returns true when the site has an active non-expired license (trial or unlimited).
     */
    public static function is_licensed(): bool {
        $s = self::get_status();
        return in_array( $s['status'], [ self::STATUS_VALID, self::STATUS_TRIAL ], true );
    }

    /**
     * Activate a new license key.
     * Stores the key and clears the transient so the next status call re-validates.
     *
     * @param  string $raw_key  Raw input from the form (may contain dashes/spaces/prefix).
     * @return array  Validation result array.
     */
    public static function activate( string $raw_key ): array {
        $result = self::validate_raw( $raw_key );

        if ( in_array( $result['status'], [ self::STATUS_VALID, self::STATUS_TRIAL ], true ) ) {
            // Store canonical form (PXLF-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX).
            update_option( self::OPTION_KEY, self::canonical( $raw_key ), false );
            delete_transient( self::CACHE_TRANSIENT );
            set_transient( self::CACHE_TRANSIENT, $result, self::CACHE_TTL );
        }

        return $result;
    }

    /**
     * Remove the stored license key and clear the status cache.
     */
    public static function deactivate(): void {
        delete_option( self::OPTION_KEY );
        delete_transient( self::CACHE_TRANSIENT );
    }

    // ── Validation ─────────────────────────────────────────────────────────────

    /**
     * Validate a raw key string (may include dashes, spaces, 'PXLF' prefix).
     */
    public static function validate_raw( string $raw_key ): array {
        // Strip the PXLF- prefix first — 'F' in PXLF is a valid hex char and
        // would inflate the count to 33 if left in before hex extraction.
        $stripped = preg_replace( '/^PXLF-?/i', '', trim( $raw_key ) );
        $hex      = preg_replace( '/[^A-Fa-f0-9]/', '', $stripped );

        if ( 32 !== strlen( $hex ) ) {
            return self::make_result(
                self::STATUS_INVALID,
                '',
                0,
                __( 'Invalid key format. Keys are 32 hex characters (PXLF-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX).', 'pixlify-image-optimizer' )
            );
        }

        $bytes = hex2bin( $hex );

        // ── Parse components ───────────────────────────────────────────────────
        $type_byte   = ord( $bytes[0] );
        $expiry_data = unpack( 'N', substr( $bytes, 1, 4 ) ); // big-endian uint32
        $expiry_ts   = (int) $expiry_data[1];
        // Bytes 5–7: nonce — not validated, only used in signature.
        $stored_hmac = substr( $bytes, 8, 8 );                // 8-byte / 16-hex signature

        // ── Verify HMAC ────────────────────────────────────────────────────────
        $payload       = substr( $bytes, 0, 8 );
        $full_hmac     = hash_hmac( 'sha256', $payload, PIXLIFY_LICENSE_SECRET, true );
        $expected_hmac = substr( $full_hmac, 0, 8 );

        if ( ! hash_equals( $expected_hmac, $stored_hmac ) ) {
            return self::make_result(
                self::STATUS_INVALID,
                '',
                0,
                __( 'This license key is not valid. Please check the key and try again.', 'pixlify-image-optimizer' )
            );
        }

        // ── Validate type ──────────────────────────────────────────────────────
        if ( ! in_array( $type_byte, [ self::TYPE_TRIAL, self::TYPE_UNLIMITED ], true ) ) {
            return self::make_result(
                self::STATUS_INVALID,
                '',
                0,
                __( 'Unrecognised license type.', 'pixlify-image-optimizer' )
            );
        }

        $type_str = ( self::TYPE_TRIAL === $type_byte ) ? 'trial' : 'unlimited';

        // ── Check expiry ───────────────────────────────────────────────────────
        $now      = time();
        $days_left = 0;

        if ( $expiry_ts > 0 && $now > $expiry_ts ) {
            return self::make_result(
                self::STATUS_EXPIRED,
                $type_str,
                $expiry_ts,
                __( 'Your license has expired. WebP and AVIF serving has been paused. Renew at nandann.com/pixlify-image-optimizer.', 'pixlify-image-optimizer' )
            );
        }

        if ( $expiry_ts > 0 ) {
            $days_left = max( 1, (int) ceil( ( $expiry_ts - $now ) / DAY_IN_SECONDS ) );
        }

        $status = ( 'trial' === $type_str ) ? self::STATUS_TRIAL : self::STATUS_VALID;

        if ( 'trial' === $type_str ) {
            $message = sprintf(
                /* translators: %d number of days remaining */
                _n(
                    '%d day left in your trial — all features active.',
                    '%d days left in your trial — all features active.',
                    $days_left,
                    'pixlify-image-optimizer'
                ),
                $days_left
            );
        } else {
            $message = __( 'License active. All features unlocked.', 'pixlify-image-optimizer' );
        }

        return self::make_result( $status, $type_str, $expiry_ts, $message, $days_left );
    }

    // ── Key generator (used by the developer tool) ─────────────────────────────

    /**
     * Generate a signed license key.
     * Call from the generate-key.php CLI tool — never from a web request.
     *
     * @param  string   $type     'trial' or 'unlimited'
     * @param  int|null $expiry   Unix timestamp (null = no expiry)
     * @return string             Formatted key: PXLF-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX
     */
    public static function generate( string $type, ?int $expiry ): string {
        $type_byte  = ( 'trial' === $type ) ? self::TYPE_TRIAL : self::TYPE_UNLIMITED;
        $expiry_ts  = (int) ( $expiry ?? 0 );
        $nonce      = random_bytes( 3 );

        // Pack: type(1) + expiry(4 big-endian) + nonce(3) = 8 bytes payload
        $payload = chr( $type_byte ) . pack( 'N', $expiry_ts ) . $nonce;

        // HMAC — take first 8 bytes of SHA-256 HMAC
        $hmac     = hash_hmac( 'sha256', $payload, PIXLIFY_LICENSE_SECRET, true );
        $sig      = substr( $hmac, 0, 8 );

        $raw_hex  = strtoupper( bin2hex( $payload . $sig ) ); // 32 hex chars
        return self::format_key( $raw_hex );
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    /** Format 32 hex chars as PXLF-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX */
    public static function format_key( string $hex ): string {
        $hex = strtoupper( preg_replace( '/[^A-Fa-f0-9]/', '', $hex ) );
        return 'PXLF-' . implode( '-', str_split( $hex, 8 ) );
    }

    /** Strip the PXLF- prefix and all non-hex chars to get the 32-char canonical hex. */
    public static function canonical( string $raw ): string {
        $stripped = preg_replace( '/^PXLF-?/i', '', trim( $raw ) );
        $hex      = strtoupper( preg_replace( '/[^A-Fa-f0-9]/', '', $stripped ) );
        return self::format_key( $hex );
    }

    private static function make_result(
        string $status,
        string $type = '',
        int $expires_at = 0,
        string $message = '',
        int $days_left = 0
    ): array {
        if ( '' === $message ) {
            $message = self::default_message( $status );
        }
        return compact( 'status', 'type', 'expires_at', 'days_left', 'message' );
    }

    private static function default_message( string $status ): string {
        switch ( $status ) {
            case self::STATUS_UNLICENSED:
                return __( 'No license key entered. WebP & AVIF serving is paused.', 'pixlify-image-optimizer' );
            case self::STATUS_EXPIRED:
                return __( 'Your license has expired. Renew at nandann.com/pixlify-image-optimizer to restore WebP & AVIF serving.', 'pixlify-image-optimizer' );
            case self::STATUS_INVALID:
                return __( 'License key is not valid.', 'pixlify-image-optimizer' );
            default:
                return '';
        }
    }
}
